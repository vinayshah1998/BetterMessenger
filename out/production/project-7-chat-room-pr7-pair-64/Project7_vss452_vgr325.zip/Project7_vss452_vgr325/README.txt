README:
Vinay Shah, vss452
Vignesh Ravi, vgr325

Files:
assignment7.fxml
ChatClient.java
ChatServer.java
ClientObserver.java
Conversation.java
Header.java
Main.java

Testing:
Tested on single computer, and across multiple computers. Tested socket connections and correct performance of Observer design pattern.

Git URL: https://github.com/EE422C/project-7-chat-room-pr7-pair-64/